NaiveBayesClassifier
====================

Implementation of Multinomial Naive Bayes Text Classifier.

For more information concerning the Machine Learning model check out:

http://blog.datumbox.com/developing-a-naive-bayes-text-classifier-in-java/

http://blog.datumbox.com/machine-learning-tutorial-the-naive-bayes-text-classifier/

http://blog.datumbox.com/using-feature-selection-methods-in-text-classification/


Useful Links
============

Datumbox: http://www.datumbox.com/

Machine Learning Blog: http://blog.datumbox.com/
